# Ghazipur

Fresh, location-aware local discovery and booking marketplace foundation.

## Run

```bash
npm install
npm run dev
```

## Architecture

Ghazipur is the launch market, not a hard-coded platform location. Customer location can come from browser geolocation or manual city/locality selection. Real businesses should be loaded from Supabase; the UI intentionally uses empty states until real data is connected.

## Next implementation layers

1. Supabase schema/auth/RLS
2. Real geocoding and nearby queries
3. Business onboarding and verification
4. Search/filter/discovery data
5. Booking concurrency + payments
6. Customer/business/admin dashboards
7. Optional AI discovery
