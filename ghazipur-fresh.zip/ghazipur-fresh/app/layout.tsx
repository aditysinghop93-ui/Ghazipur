import './globals.css';
export const metadata={title:'Ghazipur — Discover what is around you',description:'Local discovery and booking marketplace'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
